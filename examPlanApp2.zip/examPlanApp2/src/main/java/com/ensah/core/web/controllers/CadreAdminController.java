package com.ensah.core.web.controllers;
import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.services.ICadreAdminService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Controller
@RequestMapping("")
public class CadreAdminController {

    @Autowired
    private ICadreAdminService cadreAdminService;

    @GetMapping("/showCadreAdminForm")
    public String showForm(Model model) {
        model.addAttribute("cadreAdmin", new CadreAdministrateur());
        return "cadreAdminForm";
    }

    @PostMapping("/addCadreAdmin")
    public String addCadreAdmin(@Valid @ModelAttribute("cadreAdmin") CadreAdministrateur cadreAdmin, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "cadreAdminForm";
        }
        cadreAdminService.saveCadreAdmin(cadreAdmin);
        return "redirect:/manageCadreAdmins";
    }

    @GetMapping("/updateCadreAdminForm/{idCadreAdmin}")
    public String updateCadreAdminForm(@PathVariable("idCadreAdmin") Long idCadreAdmin, Model model) {
        CadreAdministrateur cadreAdmin = cadreAdminService.getCadreAdminById(idCadreAdmin);
        model.addAttribute("cadreAdmin", cadreAdmin);
        return "updateCadreAdminForm";
    }

    @PostMapping("/updateCadreAdmin")
    public String updateCadreAdmin(@Valid @ModelAttribute("cadreAdmin") CadreAdministrateur cadreAdmin, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "updateCadreAdminForm";
        }
        cadreAdminService.updateCadreAdmin(cadreAdmin);
        return "redirect:/manageCadreAdmins";
    }

    @GetMapping("/deleteCadreAdmin/{idCadreAdmin}")
    public String deleteCadreAdmin(@PathVariable("idCadreAdmin") Long idCadreAdmin) {
        cadreAdminService.deleteCadreAdmin(idCadreAdmin);
        return "redirect:/manageCadreAdmins";
    }

    @GetMapping("/manageCadreAdmins")
    public String manageCadreAdmins(Model model) {
        List<CadreAdministrateur> cadreAdmins = cadreAdminService.getAllCadreAdmins();
        model.addAttribute("cadreAdminList", cadreAdmins);
        return "listCadreAdmins";
    }
}
