package com.ensah.core.bo;


public enum Session {
    NORMALE("Normale"),
    RATTRAPAGE("Rattrapage");

    private final String value;

    Session(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}