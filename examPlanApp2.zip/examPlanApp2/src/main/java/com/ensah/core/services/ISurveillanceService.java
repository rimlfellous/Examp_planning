package com.ensah.core.services;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Surveillance;

import java.util.List;

public interface ISurveillanceService {

    Surveillance saveSurveillance(Surveillance surveillance);

    List<Surveillance> getAllSurveillances();

    Surveillance getSurveillanceById(Long id);

    List<Surveillance> getSurveillancesByExamen(Long idExamen);

    List<Surveillance> getSurveillancesByEnseignant(Long idEnseignant);

    List<Surveillance> getSurveillancesByCadreAdmin(Long idCadreAdmin);

    List<Surveillance> getSurveillancesBySalle(Long idSalle);
 
   void assignControlleurRandomly(Surveillance surveillance);
   
   Enseignant getCordonnateurByElementPedagogiqueId(Long idElementPedagogique);
   void addCoordinatorToSurveillance(Long elementPedagogiqueId, Long idExamen);
   void deleteByExamenId(Long examenId);
   void assignSurveillantsRandomly(Examen examen, List<Salle> salles, int nbreEnseignant);
   void assignSurveillantsByGroup(Examen examen, List<Salle> salles, int nbreEnseignant, Long idGroupe);


}
