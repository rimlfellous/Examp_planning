package com.ensah.core.web.models;

import java.util.Set;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
public class ExamDetailsDTO {
    private Examen examen;
    private Set<Salle> salles;
    private Enseignant cordonnateur;
    private CadreAdministrateur controleurAbsence;
    private Set<Enseignant> surveillants;
    private String pv; 
    private String rapport; 
    private String epreuve; 
    private int dureeReelle;

    public ExamDetailsDTO(Examen examen, Set<Salle> salles, Enseignant cordonnateur,
                          CadreAdministrateur controleurAbsence, Set<Enseignant> surveillants,
                          String pv, String rapport, String epreuve, int dureeReelle) {
        this.examen = examen;
        this.salles = salles;
        this.cordonnateur = cordonnateur;
        this.controleurAbsence = controleurAbsence;
        this.surveillants = surveillants;
        this.pv = pv;
        this.rapport = rapport;
        this.epreuve = epreuve;
        this.dureeReelle = dureeReelle;
    }

  
    public Examen getExamen() {
        return examen;
    }

    public String getPv() {
		return pv;
	}

	public void setPv(String pv) {
		this.pv = pv;
	}

	public String getRapport() {
		return rapport;
	}

	public void setRapport(String rapport) {
		this.rapport = rapport;
	}

	public String getEpreuve() {
		return epreuve;
	}

	public void setEpreuve(String epreuve) {
		this.epreuve = epreuve;
	}

	public int getDureeReelle() {
		return dureeReelle;
	}

	public void setDureeReelle(int dureeReelle) {
		this.dureeReelle = dureeReelle;
	}

	public void setExamen(Examen examen) {
        this.examen = examen;
    }

    public Set<Salle> getSalles() {
        return salles;
    }

    public void setSalles(Set<Salle> salles) {
        this.salles = salles;
    }

    public Enseignant getCordonnateur() {
        return cordonnateur;
    }

    public void setCordonnateur(Enseignant cordonnateur) {
        this.cordonnateur = cordonnateur;
    }

    public CadreAdministrateur getControleurAbsence() {
        return controleurAbsence;
    }

    public void setControleurAbsence(CadreAdministrateur controleurAbsence) {
        this.controleurAbsence = controleurAbsence;
    }

    public Set<Enseignant> getSurveillants() {
        return surveillants;
    }

    public void setSurveillants(Set<Enseignant> surveillants) {
        this.surveillants = surveillants;
    }
}
