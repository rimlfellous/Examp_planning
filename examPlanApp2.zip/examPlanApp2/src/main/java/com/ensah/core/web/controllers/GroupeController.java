package com.ensah.core.web.controllers;
import com.ensah.core.bo.Groupe;
import com.ensah.core.services.IDepartementService;
import com.ensah.core.services.IEnseignantService;
import com.ensah.core.services.IFiliereService;
import com.ensah.core.services.IGroupeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("")
public class GroupeController {

    @Autowired
    private IGroupeService groupeService;

    @Autowired
    private IDepartementService departementService;

    @Autowired
    private IEnseignantService enseignantService;

    @Autowired
    private IFiliereService filiereService;

    @GetMapping("/GroupeForm")
    public String showCreateGroupeForm(Model model) {
        model.addAttribute("departments", departementService.getAllDepartements());
        model.addAttribute("enseignants", enseignantService.getAllEnseignants());
        model.addAttribute("filieres", filiereService.getAllFilieres());
        return "GroupeForm";
    }

  /*  @PostMapping("/createGroup")
    public String createGroup(
            @RequestParam("nomGroupe") String nomGroupe,
            @RequestParam("groupType") String groupType,
            @RequestParam(value = "departmentId", required = false) Long departmentId,
            @RequestParam(value = "filiereId", required = false) Long filiereId,
            @RequestParam(value = "enseignantIds", required = false) String[] enseignantIds, // Change parameter type to String[]
            Model model) {

        List<Long> enseignantIdList = Arrays.stream(enseignantIds) // Convert array of strings to List<Long>
                .map(Long::parseLong)
                .collect(Collectors.toList());

        switch (groupType) {
            case "department":
                groupeService.createGroupByDepartment(departmentId, nomGroupe);
                break;
            case "filiere":
                groupeService.createGroupByFiliere(filiereId, nomGroupe);
                break;
            case "custom":
                groupeService.createCustomGroup(enseignantIdList, nomGroupe); // Pass the converted List<Long> to the service method
                break;
            default:
                throw new IllegalArgumentException("Invalid group type");
        }
        return "redirect:/listGroupes";
    }
*/
    
    @PostMapping("/createGroup")
    public String createGroup(
            @RequestParam("nomGroupe") String nomGroupe,
            @RequestParam("groupType") String groupType,
            @RequestParam(value = "departmentId", required = false) Long departmentId,
            @RequestParam(value = "filiereId", required = false) Long filiereId,
            @RequestParam(value = "enseignantIds", required = false) String[] enseignantIds, 
            Model model) {

        switch (groupType) {
            case "department":
                groupeService.createGroupByDepartment(departmentId, nomGroupe);
                break;
            case "filiere":
                groupeService.createGroupByFiliere(filiereId, nomGroupe);
                break;
            case "custom":
                if (enseignantIds == null) {
                    throw new IllegalArgumentException("enseignantIds cannot be null for custom group type");
                }
                List<Long> enseignantIdList = Arrays.stream(enseignantIds)
                        .map(Long::parseLong)
                        .collect(Collectors.toList());
                groupeService.createCustomGroup(enseignantIdList, nomGroupe); 
                break;
            default:
                throw new IllegalArgumentException("Invalid group type");
        }
        return "redirect:/listGroupes";
    }


    @GetMapping("/listGroupes")
    public String listGroupes(Model model) {
        model.addAttribute("groupes", groupeService.getAllGroups());
        return "listGroupes";
    }

    @GetMapping("/editGroupeForm/{idGroupe}")
    public String showEditGroupeForm(@PathVariable("idGroupe") Long idGroupe, Model model) {
        Groupe groupe = groupeService.getGroupById(idGroupe);
        model.addAttribute("groupe", groupe);
        return "editGroupeForm";
    }

    @PostMapping("/updateGroupe")
    public String updateGroupe(@ModelAttribute Groupe groupe) {
        groupeService.updateGroup(groupe);
        return "redirect:/listGroupes";
    }

    @GetMapping("/deleteGroupe/{idGroupe}")
    public String deleteGroupe(@PathVariable("idGroupe") Long idGroupe) {
        groupeService.deleteGroup(idGroupe);
        return "redirect:/listGroupes";
    }
}
