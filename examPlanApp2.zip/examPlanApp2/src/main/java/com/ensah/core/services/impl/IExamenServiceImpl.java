package com.ensah.core.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.Session;
import com.ensah.core.bo.TypeExamen;
import com.ensah.core.dao.IExamenRepository;
import com.ensah.core.services.IExamenService;

import jakarta.transaction.Transactional;

import java.util.List;

@Service
public class IExamenServiceImpl implements IExamenService {
	@Autowired
    private IExamenRepository examenRepository;
    


	@Override
    public Examen saveExamen(Examen examen) {
        return examenRepository.save(examen);
    }

    @Override
    public Examen updateExamen(Examen examen) {
        return examenRepository.save(examen);
    }

    @Override
    @Transactional
    public void deleteExamen(Long id) {
        examenRepository.deleteById(id);
    }

    @Override
    public Examen getExamenById(Long id) {
        return examenRepository.findById(id).orElse(null);
    }

    @Override
    public List<Examen> getAllExamen() {
        return examenRepository.findAll();
    }
    @Override
    public List<Examen> getExamsBySemestre(Semestre semestre) {
        return examenRepository.findBySemestre(semestre);
    }

    @Override
    public List<Examen> getExamsBySession(Session session) {
        return examenRepository.findBySession(session);
    }

    @Override
    public List<Examen> getExamsByType(TypeExamen typeExamen) {
        return examenRepository.findByTypeExamen(typeExamen);
    }


    @Override
    public List<Examen> getExamsByElementPedagogique(String titreElementPedagogique) {
        return examenRepository.findByElementPedagogique_Titre(titreElementPedagogique);
    }

    @Override
    public String generateDetailedExamReport(Long idExamen) {
        Examen examen = getExamenById(idExamen);
        if (examen != null) {
            return "Detailed Report for Exam: " + examen.toString();
        } else {
            return "Examen not found";
        }
    }
}
