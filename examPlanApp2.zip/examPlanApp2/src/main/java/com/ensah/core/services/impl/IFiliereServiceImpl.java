package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.Filiere;
import com.ensah.core.dao.IFiliereRepository;
import com.ensah.core.services.IFiliereService;

@Service
@Transactional
public class IFiliereServiceImpl implements IFiliereService {
	@Autowired
    private IFiliereRepository filiereRepository;
    


	@Override
    public Filiere saveFiliere(Filiere filiere) {
        return filiereRepository.save(filiere);
    }

    @Override
    public Filiere updateFiliere(Filiere filiere) {
        return filiereRepository.save(filiere);
    }

    @Override
    public void deleteFiliere(Long id) {
        filiereRepository.deleteById(id);
    }

    @Override
    public Filiere getFiliereById(Long id) {
        return filiereRepository.findById(id).orElse(null);
    }

    @Override
    public List<Filiere> getAllFilieres() {
        return filiereRepository.findAll();
    }
}
