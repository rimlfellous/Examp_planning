package com.ensah.core.web.controllers;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.services.IDepartementService;
import com.ensah.core.services.IEnseignantService;
import com.ensah.core.services.IFiliereService;
import com.ensah.core.services.IGroupeService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("")
public class EnseignantController {

	@Autowired
    private IEnseignantService enseignantService;

    @Autowired
    private IDepartementService departementService;

    @Autowired
    private IFiliereService filiereService;

    @Autowired
    private IGroupeService groupeService;

    @GetMapping("/showForm")
    public String showForm(Model model) {
    	 model.addAttribute("enseignant", new Enseignant());
         model.addAttribute("departementList", departementService.getAllDepartements());
         model.addAttribute("filiereList", filiereService.getAllFilieres());
         model.addAttribute("groupeList", groupeService.getAllGroups());
        return "enseignantForm";
    }

    @PostMapping("/addEnseignant")
    public String addEnseignant(@Valid @ModelAttribute("enseignant") Enseignant enseignant, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "enseignantForm";
        }
        enseignantService.saveEnseignant(enseignant);
        return "redirect:/manageEnseignants";
    }

    @GetMapping("/updateEnseignantForm/{idEnseignant}")
    public String updateEnseignantForm(@PathVariable("idEnseignant") Long idEnseignant, Model model) {
        Enseignant enseignant = enseignantService.getEnseignantById(idEnseignant);
        model.addAttribute("enseignant", enseignant);
        return "updateEnseignantForm";
    }

    @PostMapping("/updateEnseignant")
    public String updateEnseignant(@Valid @ModelAttribute("enseignant") Enseignant enseignant, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "updateEnseignantForm";
        }
        enseignantService.updateEnseignant(enseignant);
        return "redirect:/manageEnseignants";
    }

    @GetMapping("/deleteEnseignant/{idEnseignant}")
    public String deleteEnseignant(@PathVariable("idEnseignant") Long idEnseignant) {
        enseignantService.deleteEnseignant(idEnseignant);
        return "redirect:/manageEnseignants";
    }

  
    @GetMapping("/manageEnseignants")
    public String manageEnseignants(Model model) {
        List<Enseignant> enseignants = enseignantService.getAllEnseignants();
        model.addAttribute("enseignantList", enseignants);
        return "listEnseignants";
    }
}
