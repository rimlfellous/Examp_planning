package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.Niveau;
import com.ensah.core.dao.INiveauRepository;
import com.ensah.core.services.INiveauService;

@Service
@Transactional
public class INiveauServiceImpl implements INiveauService {
	@Autowired
    private INiveauRepository niveauRepository;
    


	@Override
    public Niveau saveNiveau(Niveau niveau) {
        return niveauRepository.save(niveau);
    }

    @Override
    public Niveau updateNiveau(Niveau niveau) {
        return niveauRepository.save(niveau);
    }

    @Override
    public void deleteNiveau(Long id) {
        niveauRepository.deleteById(id);
    }

    @Override
    public Niveau getNiveauById(Long id) {
        return niveauRepository.findById(id).orElse(null);
    }

    @Override
    public List<Niveau> getAllNiveaux() {
        return niveauRepository.findAll();
    }
}
