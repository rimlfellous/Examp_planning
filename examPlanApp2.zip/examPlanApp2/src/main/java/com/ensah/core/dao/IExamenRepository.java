package com.ensah.core.dao;

import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.Session;
import com.ensah.core.bo.TypeExamen;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IExamenRepository extends JpaRepository<Examen, Long> {
	List<Examen> findByElementPedagogique_Titre(String titre);
	List<Examen> findBySession(Session session);
    List<Examen> findBySemestre(Semestre semestre);
    List<Examen> findByTypeExamen(TypeExamen typeExamen);
}
