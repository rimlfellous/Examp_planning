package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Groupe;

public interface IGroupeService {
    void addGroup(Groupe group);
    void deleteGroup(Long id);
    void updateGroup(Groupe group);
    List<Groupe> getAllGroups();
    Groupe getGroupById(Long id);
    Groupe saveGroupe(Groupe groupe);
   /* Groupe createGroupByDepartment(Long departmentId);
    Groupe createCustomGroup(List<Long> enseignantIds);
	Groupe createGroupByFiliere(Long filiereId);*/
    Groupe createGroupByDepartment(Long departmentId, String nomGroupe);

    Groupe createGroupByFiliere(Long filiereId, String nomGroupe);

    Groupe createCustomGroup(List<Long> enseignantIds, String nomGroupe);
}