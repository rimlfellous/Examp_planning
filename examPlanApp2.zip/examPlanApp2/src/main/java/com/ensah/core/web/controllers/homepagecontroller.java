package com.ensah.core.web.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class homepagecontroller {

    @GetMapping("")
    public String showNavigationBar() {
        return "Homepage"; // This will return the name of your Thymeleaf template (navigation.html)
    }
}
