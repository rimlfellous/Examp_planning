package com.ensah.core.services;
import java.util.List;

import com.ensah.core.bo.Departement;

public interface IDepartementService {
    Departement saveDepartement(Departement departement);
    Departement updateDepartement(Departement departement);
    void deleteDepartement(Long id);
    Departement getDepartementById(Long id);
    List<Departement> getAllDepartements();
}
