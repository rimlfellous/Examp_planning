package com.ensah.core.services;
import java.util.List;

import com.ensah.core.bo.Personne;

public interface IPersonneService {
    Personne savePersonne(Personne personne);
    Personne updatePersonne(Personne personne);
    void deletePersonne(Long id);
    Personne getPersonneById(Long id);
    List<Personne> getAllPersonnes();
    //List<Personne> getPersonnesByType(String typePersonne);
}
