package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Enseignant;


public interface IEnseignantService {

	Enseignant saveEnseignant(Enseignant enseignant);
    Enseignant updateEnseignant(Enseignant enseignant);
    void deleteEnseignant(Long id);
    Enseignant getEnseignantById(Long id);
    List<Enseignant> getAllEnseignants();
    List<Enseignant> getEnseignantsByGroupe(Long idGroupe);
    List<Enseignant> getEnseignantsByFiliere(Long idFiliere);
    List<Enseignant> getEnseignantsByDepartement(Long idDepartement);
    List<Enseignant> getEnseignantsBySurveillance(Long idSurveillance);
    
    void assignSurveillanceToEnseignant(Long EnseignantId, Long surveillanceId);
    
   /* List<Enseignant> getAvailableEnseignants();

    List<Enseignant> getAvailableEnseignantsByGroup(Long groupId);*/

   
}
