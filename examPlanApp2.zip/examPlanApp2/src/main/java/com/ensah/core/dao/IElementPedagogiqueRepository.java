package com.ensah.core.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;

public interface IElementPedagogiqueRepository  extends JpaRepository<ElementPedagogique, Long> {
	List<ElementPedagogique> findByNiveau_idNiveau(Long idNiveau);
    List<ElementPedagogique> findByCordonnateur(Enseignant cordonnateur);
    @Query("SELECT e.cordonnateur FROM ElementPedagogique e WHERE e.idElementPedagogique = :idElementPedagogique")
    Enseignant findCordonnateurByIdElementPedagogique(@Param("idElementPedagogique") Long idElementPedagogique);
}
	

	


