package com.ensah.core.bo;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Salle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSalle;

    private String numero;
    
    private int capacite;

    @OneToMany(mappedBy = "salle")
    private Set<Surveillance> surveillances;


	

	public Salle(Long idSalle, String numero, int capacite, Set<Surveillance> surveillances) {
		super();
		this.idSalle = idSalle;
		this.numero = numero;
		this.capacite = capacite;
		this.surveillances = surveillances;
	}



	public Long getIdSalle() {
		return idSalle;
	}



	public void setIdSalle(Long idSalle) {
		this.idSalle = idSalle;
	}



	public Salle() {
		super();
	}

	

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Set<Surveillance> getSurveillances() {
		return surveillances;
	}

	public void setSurveillances(Set<Surveillance> surveillances) {
		this.surveillances = surveillances;
	}

	public int getCapacite() {
		return capacite;
	}

	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}

    
}
