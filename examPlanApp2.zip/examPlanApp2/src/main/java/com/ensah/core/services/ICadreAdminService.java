package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Surveillance;

public interface ICadreAdminService {
    CadreAdministrateur saveCadreAdmin(CadreAdministrateur cadreAdmin);
    CadreAdministrateur updateCadreAdmin(CadreAdministrateur cadreAdmin);
    void deleteCadreAdmin(Long id);
    CadreAdministrateur getCadreAdminById(Long id);
    List<CadreAdministrateur> getAllCadreAdmins();
    
    List<Surveillance> getSurveillancesByCadreAdmin(Long idCadreAdmin);
    void assignSurveillanceToCadreAdmin(Long cadreAdminId, Long surveillanceId);
   
}

