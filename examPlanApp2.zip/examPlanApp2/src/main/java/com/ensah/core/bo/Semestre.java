package com.ensah.core.bo;


public enum Semestre {
    PRINTEMPS("Printemps"),
    AUTOMNE("Automne");

    private final String value;

    Semestre(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}