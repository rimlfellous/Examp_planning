package com.ensah.core.bo;


import java.util.Set;

import jakarta.persistence.*;


@Entity
@PrimaryKeyJoinColumn(name = "idEnseighant")
@DiscriminatorValue("Enseignant")
public class Enseignant extends Personne {

	
	@ManyToOne
    @JoinColumn(name = "idFiliere")
    private Filiere filiere;
	@ManyToOne
    @JoinColumn(name = "idDepartement")
    private Departement departement;
	
	 @ManyToMany
	 @JoinTable(
	        name = "enseignant_surveillance",
	        joinColumns = @JoinColumn(name = "enseignant_id"),
	        inverseJoinColumns = @JoinColumn(name = "surveillance_id")
	    )
	private Set<Surveillance> additionalSurveillances;
	
	
	 @ManyToOne
	 @JoinColumn(name = "groupe_id")
	 private Groupe groupe;
	
	@OneToMany(mappedBy = "cordonnateur")
	private Set<ElementPedagogique> elementPedagogiques;

	@OneToMany(mappedBy = "enseignant")
    private Set<Surveillance> surveillances;
	





	
	
	public Enseignant() {
		super();
	}



	public Enseignant(Filiere filiere, Departement departement, Set<Surveillance> additionalSurveillances,
			Groupe groupe, Set<ElementPedagogique> elementPedagogiques, Set<Surveillance> surveillances) {
		super();
		this.filiere = filiere;
		this.departement = departement;
		this.additionalSurveillances = additionalSurveillances;
		this.groupe = groupe;
		this.elementPedagogiques = elementPedagogiques;
		this.surveillances = surveillances;
	}



	public Set<Surveillance> getAdditionalSurveillances() {
		return additionalSurveillances;
	}



	public void setAdditionalSurveillances(Set<Surveillance> additionalSurveillances) {
		this.additionalSurveillances = additionalSurveillances;
	}



	public Groupe getGroupe() {
		return groupe;
	}



	public void setGroupe(Groupe groupe) {
		this.groupe = groupe;
	}



	public Set<ElementPedagogique> getElementPedagogiques() {
		return elementPedagogiques;
	}



	public void setElementPedagogiques(Set<ElementPedagogique> elementPedagogiques) {
		this.elementPedagogiques = elementPedagogiques;
	}



	public Set<Surveillance> getSurveillances() {
		return surveillances;
	}



	public void setSurveillances(Set<Surveillance> surveillances) {
		this.surveillances = surveillances;
	}




	public Departement getDepartement() {
		return departement;
	}



	public void setDepartement(Departement departement) {
		this.departement = departement;
	}



	public Filiere getFiliere() {
		return filiere;
	}

	public void setFiliere(Filiere filiere) {
		this.filiere = filiere;
	}


}