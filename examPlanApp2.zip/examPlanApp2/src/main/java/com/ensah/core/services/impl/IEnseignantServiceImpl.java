package com.ensah.core.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.ISurveillanceRepository;
import com.ensah.core.services.IEnseignantService;
import com.ensah.core.services.exceptions.EntityNotFoundException;

import jakarta.transaction.Transactional;

import java.util.List;

@Service
public class IEnseignantServiceImpl implements IEnseignantService {
	@Autowired
    private IEnseignantRepository enseignantRepository;
	@Autowired
    private ISurveillanceRepository ISurveillanceRepository;

    

	@Override
    public Enseignant saveEnseignant(Enseignant enseignant) {
        return enseignantRepository.save(enseignant);
    }

    @Override
    public Enseignant updateEnseignant(Enseignant enseignant) {
        return enseignantRepository.save(enseignant);
    }

    @Override
    public void deleteEnseignant(Long id) {
        enseignantRepository.deleteById(id);
    }

    @Override
    public Enseignant getEnseignantById(Long id) {
        return enseignantRepository.findById(id).orElse(null);
    }

    @Override
    public List<Enseignant> getAllEnseignants() {
        return enseignantRepository.findAll();
    }

    @Override
    public List<Enseignant> getEnseignantsByGroupe(Long idGroupe) {
        return enseignantRepository.findByGroupe_IdGroupe(idGroupe);
    }

    @Override
    public List<Enseignant> getEnseignantsByFiliere(Long idFiliere) {
        return enseignantRepository.findByFiliere_IdFiliere(idFiliere);
    }

    @Override
    public List<Enseignant> getEnseignantsByDepartement(Long idDepartement) {
        return enseignantRepository.findByDepartement_IdDepartement(idDepartement);
    }

    @Override
    public List<Enseignant> getEnseignantsBySurveillance(Long idSurveillance) {
        return enseignantRepository.findBySurveillances_IdS(idSurveillance);
    }
    @Override
    @Transactional
    public void assignSurveillanceToEnseignant(Long enseignantId, Long surveillanceId) {
        Enseignant enseignant = enseignantRepository.findById(enseignantId)
                .orElseThrow(() -> new EntityNotFoundException("Enseignant not found with id: " + enseignantId));

        Surveillance surveillance = ISurveillanceRepository.findById(surveillanceId)
                .orElseThrow(() -> new EntityNotFoundException("Surveillance not found with id: " + surveillanceId));

        enseignant.getSurveillances().add(surveillance);
        surveillance.setEnseignant(enseignant);
    }
    
   /* @Override
    public List<Enseignant> getAvailableEnseignants() {
        List<Long> assignedEnseignantIds = ISurveillanceRepository.findAssignedEnseignantIds();
        return enseignantRepository.findByIdNotIn(assignedEnseignantIds);
    }

    @Override
    public List<Enseignant> getAvailableEnseignantsByGroup(Long groupId) {
        List<Long> assignedEnseignantIds = ISurveillanceRepository.findAssignedEnseignantIds();
        return enseignantRepository.findByGroupeIdAndIdNotIn(groupId, assignedEnseignantIds);
    }*/
}
