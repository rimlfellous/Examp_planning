package com.ensah.core.bo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.ensah.core.dao.ICompteRepository;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ICompteRepository compteRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create an admin user
        if (compteRepository.findByLogin("admin") == null) {
            Compte admin = new Compte();
            admin.setLogin("admin");
            admin.setPassword(passwordEncoder.encode("admin"));
            compteRepository.save(admin);
        }
    }
}