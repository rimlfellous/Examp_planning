package com.ensah.core.bo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToOne;

@Entity
public class ElementPedagogique {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idElementPedagogique;
	
	private String titre;
	
	@ManyToOne
	@JoinColumn(name = "idEnseighant")
	private Enseignant cordonnateur;

	
	@ManyToOne
    @JoinColumn(name = "idNiveau")
    private Niveau niveau;
	
	@ManyToOne
    @JoinColumn(name = "idTypeElement")
    private TypeElement typeElement;
	


	
	

	public ElementPedagogique() {
		super();
	}

	public ElementPedagogique(Long idElementPedagogique, String titre) {
		super();
		this.idElementPedagogique = idElementPedagogique;
		this.titre = titre;
	
	}

	public Long getIdElementPedagogique() {
		return idElementPedagogique;
	}

	public void setidElementPedagogique(Long idElementPedagogique) {
		this.idElementPedagogique = idElementPedagogique;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Enseignant getEnseignant() {
		return cordonnateur;
	}

	public void setEnseignant(Enseignant cordonnateur) {
		this.cordonnateur = cordonnateur;
	}

	public Niveau getNiveau() {
		return niveau;
	}

	public void setNiveau(Niveau niveau) {
		this.niveau = niveau;
	}
	
	public Enseignant getCordonnateur() {
		return cordonnateur;
	}

	public void setCordonnateur(Enseignant cordonnateur) {
		this.cordonnateur = cordonnateur;
	}

	public TypeElement getTypeElement() {
		return typeElement;
	}

	public void setTypeElement(TypeElement typeElement) {
		this.typeElement = typeElement;
	}

	public void setIdElementPedagogique(Long idElementPedagogique) {
		this.idElementPedagogique = idElementPedagogique;
	}
	
	
	


}
