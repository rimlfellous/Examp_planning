package com.ensah.core.bo;

import java.util.Set;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PreRemove;

@Entity
public class Groupe {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idGroupe;

	private String nomGroupe;
	
	@OneToMany(mappedBy = "groupe")
    private Set<Enseignant> enseignants;



	
	
	@PreRemove
    private void preRemove() {
        for (Enseignant enseignant : enseignants) {
            enseignant.setGroupe(null);
        }

    }
	
	public Groupe() {
		super();
	}

	public Groupe(Long idGroupe, String nomGroupe, Set<Enseignant> enseignants) {
		super();
		this.idGroupe = idGroupe;
		this.nomGroupe = nomGroupe;
		this.enseignants = enseignants;
	}

	public Long getIdGroupe() {
		return idGroupe;
	}

	public void setIdGroupe(Long idGroupe) {
		this.idGroupe = idGroupe;
	}

	public String getNomGroupe() {
		return nomGroupe;
	}

	public void setNomGroupe(String nomGroupe) {
		this.nomGroupe = nomGroupe;
	}

	public Set<Enseignant> getEnseignants() {
		return enseignants;
	}

	public void setEnseignants(Set<Enseignant> enseignants) {
		this.enseignants = enseignants;
	}
	
	@Override
    public String toString() {
        return "Groupe{idGroupe=" + idGroupe + ", nomGroupe='" + nomGroupe + "'}";
    }
	
	
	
	
	
	
	
	
	

}
