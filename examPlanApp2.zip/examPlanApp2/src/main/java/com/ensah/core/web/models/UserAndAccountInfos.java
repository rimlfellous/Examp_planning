package com.ensah.core.web.models;

public class UserAndAccountInfos {
    private Long idCompte;
    private String login;

    public UserAndAccountInfos(Long idCompte, String login) {
        this.idCompte = idCompte;
        this.login = login;
    }

    public Long getIdCompte() {
        return idCompte;
    }

    public void setIdCompte(Long idCompte) {
        this.idCompte = idCompte;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}
