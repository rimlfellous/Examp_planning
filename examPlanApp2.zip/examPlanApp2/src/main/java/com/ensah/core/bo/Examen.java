package com.ensah.core.bo;

import java.sql.Date;
import java.time.LocalTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
@Entity
public class Examen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

   

    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "heure_debut")
    private LocalTime heureDebut;



    @Column(name = "duree_prevue")
    private int dureePrevue;

    @Column(name = "duree_reelle")
    private int dureeReelle;

    private String epreuve; // File path to exam document

    private String pv; // File path to exam record

    private String rapport; 
    
    @OneToMany(mappedBy = "examen")
    private List<Surveillance> surveillances;

    
    @ManyToOne
    @JoinColumn(name = "idElementPedagogique")
    private ElementPedagogique elementPedagogique;
    
    @Enumerated(EnumType.STRING)
    private Session session;

    @Enumerated(EnumType.STRING)
    private Semestre semestre;

    @Enumerated(EnumType.STRING)
    private TypeExamen typeExamen;


	

	public Examen(Long id, Date date, LocalTime heureDebut, int dureePrevue, int dureeReelle,
			String epreuve, String pv, String rapport, List<Surveillance> surveillances,
			ElementPedagogique elementPedagogique, Session session, Semestre semestre, TypeExamen typeExamen) {
		super();
		this.id = id;
		this.heureDebut = heureDebut;
		this.dureePrevue = dureePrevue;
		this.dureeReelle = dureeReelle;
		this.epreuve = epreuve;
		this.pv = pv;
		this.rapport = rapport;
		this.surveillances = surveillances;
		this.elementPedagogique = elementPedagogique;
		this.session = session;
		this.semestre = semestre;
		this.typeExamen = typeExamen;
	}


	public Examen() {
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public Date getDate() {
		return date;
	}

	

	public void setDate(Date date) {
		this.date = date;
	}


	public LocalTime getHeureDebut() {
		return heureDebut;
	}

	public void setHeureDebut(LocalTime heureDebut) {
		this.heureDebut = heureDebut;
	}

	public int getDureePrevue() {
		return dureePrevue;
	}

	public void setDureePrevue(int dureePrevue) {
		this.dureePrevue = dureePrevue;
	}

	public int getDureeReelle() {
		return dureeReelle;
	}

	public void setDureeReelle(int dureeReelle) {
		this.dureeReelle = dureeReelle;
	}

	public String getEpreuve() {
		return epreuve;
	}

	public void setEpreuve(String epreuve) {
		this.epreuve = epreuve;
	}

	public String getPv() {
		return pv;
	}

	public void setPv(String pv) {
		this.pv = pv;
	}

	public String getRapport() {
		return rapport;
	}

	public void setRapport(String rapport) {
		this.rapport = rapport;
	}

	

	public ElementPedagogique getElementPedagogique() {
		return elementPedagogique;
	}

	public void setElementPedagogique(ElementPedagogique elementPedagogique) {
		this.elementPedagogique = elementPedagogique;
	}

	
	public Session getSession() {
		return session;
	}


	public void setSession(Session session) {
		this.session = session;
	}


	public List<Surveillance> getSurveillances() {
		return surveillances;
	}


	public void setSurveillances(List<Surveillance> surveillances) {
		this.surveillances = surveillances;
	}


	public Semestre getSemestre() {
		return semestre;
	}


	public void setSemestre(Semestre semestre) {
		this.semestre = semestre;
	}


	public TypeExamen getTypeExamen() {
		return typeExamen;
	}


	public void setTypeExamen(TypeExamen typeExamen) {
		this.typeExamen = typeExamen;
	}


	@Override
	public String toString() {
	    return "Examen{" +
	            "id=" + id +
	            ", date=" + date +
	            
	            '}';
	}




    
    
    
    
    
}

