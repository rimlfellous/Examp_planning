package com.ensah.core.bo;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class TypeElement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idTypeElement;
	
	private String titre;
	
	@OneToMany(mappedBy = "typeElement")
	private Set<ElementPedagogique> elementsPedagogiques;


	
	public TypeElement() {
		super();
	}

	public TypeElement(Long idTypeElement, String titre, Set<ElementPedagogique> elementsPedagogiques) {
		super();
		this.idTypeElement = idTypeElement;
		this.titre = titre;
		this.elementsPedagogiques = elementsPedagogiques;
	}

	public Long getIdTypeElement() {
		return idTypeElement;
	}

	public void setIdTypeElement(Long idTypeElement) {
		this.idTypeElement = idTypeElement;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Set<ElementPedagogique> getElementsPedagogiques() {
		return elementsPedagogiques;
	}

	public void setElementsPedagogiques(Set<ElementPedagogique> elementsPedagogiques) {
		this.elementsPedagogiques = elementsPedagogiques;
	}


}
