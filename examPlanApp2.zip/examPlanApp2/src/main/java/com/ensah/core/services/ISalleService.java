package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Salle;

public interface ISalleService {
    Salle saveSalle(Salle salle);
    Salle updateSalle(Salle salle);
    void deleteSalle(Long id);
    Salle getSalleById(Long id);
    List<Salle> getAllSalles();
}
