package com.ensah;


import org.springframework.boot.SpringApplication;


import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ExamPlanAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(ExamPlanAppApplication.class, args);
    }
}