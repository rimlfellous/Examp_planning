package com.ensah.core.dao;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ensah.core.bo.Salle;


public interface ISalleRepository  extends JpaRepository<Salle, Long> {
	@Query("SELECT s FROM Salle s JOIN s.surveillances surv JOIN surv.examen ex WHERE ex.date = :date AND ex.heureDebut = :heureDebut")
    List<Salle> findUsedSallesByDateAndTime(@Param("date") Date date, @Param("heureDebut") LocalTime heureDebut);
}
