package com.ensah.core.bo;

public enum TypeExamen {
    Control("Control"),
    Devoir("Devoir");

    private final String value;

    TypeExamen(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }}