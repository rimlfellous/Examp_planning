package com.ensah.core.bo;


import java.util.Set;

import jakarta.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name="idCardreAdmin")
@DiscriminatorValue("Administrateur")
public class CadreAdministrateur extends Personne {
    
   @OneToMany(mappedBy = "cadreAdmin")
   private Set<Surveillance> surveillances;
   
   

public CadreAdministrateur() {
	super();
}



public CadreAdministrateur(Set<Surveillance> surveillances) {
	super();
	this.surveillances = surveillances;
}
   
   

}
