package com.ensah.core.bo;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Niveau {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected Long idNiveau;
	
	protected String titre;
	
	@OneToMany(mappedBy = "niveau")
    private Set<ElementPedagogique> elementsPedagogiques;

	public Niveau(Long idNiveau, String titre, Set<ElementPedagogique> elementsPedagogiques) {
		super();
		this.idNiveau = idNiveau;
		this.titre = titre;
		this.elementsPedagogiques = elementsPedagogiques;
	}

	public Niveau() {
		super();
	}

	public Long getIdNiveau() {
		return idNiveau;
	}

	public void setIdNiveau(Long idNiveau) {
		this.idNiveau = idNiveau;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Set<ElementPedagogique> getElementsPedagogiques() {
		return elementsPedagogiques;
	}

	public void setElementsPedagogiques(Set<ElementPedagogique> elementsPedagogiques) {
		this.elementsPedagogiques = elementsPedagogiques;
	}


}
