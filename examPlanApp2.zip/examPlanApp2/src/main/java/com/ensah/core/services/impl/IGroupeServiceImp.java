package com.ensah.core.services.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;
import com.ensah.core.bo.Groupe;
import com.ensah.core.dao.IDepartementRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IFiliereRepository;
import com.ensah.core.dao.IGroupeRepository;
import com.ensah.core.services.IGroupeService;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class IGroupeServiceImp implements IGroupeService {

	@Autowired
    private IGroupeRepository groupeRepository;
	@Autowired
    private IEnseignantRepository enseignantRepository;
	@Autowired
    private IDepartementRepository departementRepository;
	@Autowired
    private IFiliereRepository filiereRepository;
    
    
   
	@Override
    public void addGroup(Groupe group) {
        groupeRepository.save(group);
    }
    @Override
    public void deleteGroup(Long id) {
        groupeRepository.deleteById(id);
    }
    @Override
    public void updateGroup(Groupe group) {
        groupeRepository.save(group);
    }
    @Override
    public List<Groupe> getAllGroups() {
        return groupeRepository.findAll();
    }
    @Override
    public Groupe getGroupById(Long id) {
        Optional<Groupe> optionalGroup = groupeRepository.findById(id);
        return optionalGroup.orElse(null);
    }
    @Override
    public Groupe saveGroupe(Groupe groupe) {
        return groupeRepository.save(groupe);
    }
 
    @Override
    @Transactional
    public Groupe createGroupByDepartment(Long departmentId, String nomGroupe) {
        Optional<Departement> department = departementRepository.findById(departmentId);
        if (department.isPresent()) {
            List<Enseignant> enseignants = enseignantRepository.findByDepartement_IdDepartement(departmentId);
            Groupe groupe = new Groupe();
            groupe.setNomGroupe(nomGroupe);
            Groupe savedGroupe = groupeRepository.save(groupe);

            for (Enseignant enseignant : enseignants) {
                enseignant.setGroupe(savedGroupe);
                enseignantRepository.save(enseignant);
            }
            return savedGroupe;
        } else {
            throw new IllegalArgumentException("Department not found with id: " + departmentId);
        }
    }

    @Override
    @Transactional
    public Groupe createGroupByFiliere(Long filiereId, String nomGroupe) {
        Optional<Filiere> filiere = filiereRepository.findById(filiereId);
        if (filiere.isPresent()) {
            List<Enseignant> enseignants = enseignantRepository.findByFiliere_IdFiliere(filiereId);
            Groupe groupe = new Groupe();
            groupe.setNomGroupe(nomGroupe);
            Groupe savedGroupe = groupeRepository.save(groupe);

            for (Enseignant enseignant : enseignants) {
                enseignant.setGroupe(savedGroupe);
                enseignantRepository.save(enseignant);
            }
            return savedGroupe;
        } else {
            throw new IllegalArgumentException("Filiere not found with id: " + filiereId);
        }
    }

    @Override
    @Transactional
    public Groupe createCustomGroup(List<Long> enseignantIds, String nomGroupe) {
        Set<Enseignant> enseignants = enseignantIds.stream()
                .map(id -> enseignantRepository.findById(id)
                        .orElseThrow(() -> new IllegalArgumentException("Enseignant not found with id: " + id)))
                .collect(Collectors.toSet());
        Groupe groupe = new Groupe();
        groupe.setNomGroupe(nomGroupe);
        Groupe savedGroupe = groupeRepository.save(groupe);

        for (Enseignant enseignant : enseignants) {
            enseignant.setGroupe(savedGroupe);
            enseignantRepository.save(enseignant);
        }
        return savedGroupe;
    }
}
