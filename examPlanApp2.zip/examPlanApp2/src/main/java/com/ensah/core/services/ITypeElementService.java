package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.TypeElement;

public interface ITypeElementService {
    TypeElement saveTypeElement(TypeElement typeElement);
    TypeElement updateTypeElement(TypeElement typeElement);
    void deleteTypeElement(Long id);
    TypeElement getTypeElementById(Long id);
    List<TypeElement> getAllTypeElements();
}
