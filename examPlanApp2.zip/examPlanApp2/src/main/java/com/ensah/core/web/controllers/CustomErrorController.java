package com.ensah.core.web.controllers;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class CustomErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String errorMessage = "Unknown error";
        int errorCode = 0;

        if (status != null) {
            errorCode = Integer.parseInt(status.toString());

            switch (errorCode) {
                case 404:
                    errorMessage = "Page Not Found";
                    break;
                case 500:
                    errorMessage = "Internal Server Error";
                    break;
                default:
                    errorMessage = "Unexpected Error";
                    break;
            }
        }

        String referer = request.getHeader("Referer");
        String lastPage = (referer != null) ? referer : "/";

        model.addAttribute("errorCode", errorCode);
        model.addAttribute("errorMessage", errorMessage);
        model.addAttribute("lastPage", lastPage);

        return "error";
    }

    public String getErrorPath() {
        return "/error";
    }
}
