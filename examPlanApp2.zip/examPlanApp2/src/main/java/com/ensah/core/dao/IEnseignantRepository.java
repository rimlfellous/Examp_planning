package com.ensah.core.dao;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ensah.core.bo.Enseignant;


public interface IEnseignantRepository extends JpaRepository<Enseignant, Long> {
    List<Enseignant> findByGroupe_IdGroupe(Long idGroupe);
    
    List<Enseignant> findByFiliere_IdFiliere(Long idFiliere);
    
    List<Enseignant> findByDepartement_IdDepartement(Long idDepartement);
    
    List<Enseignant> findBySurveillances_IdS(Long idS);
    @Query("SELECT e FROM Enseignant e JOIN e.additionalSurveillances s JOIN s.examen ex WHERE ex.date = :date AND ex.heureDebut = :heureDebut")
    List<Enseignant> findUnavailableEnseignants(@Param("date") Date date, @Param("heureDebut") LocalTime heureDebut);
}