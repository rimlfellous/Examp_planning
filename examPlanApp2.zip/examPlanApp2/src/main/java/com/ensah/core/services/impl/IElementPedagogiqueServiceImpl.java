package com.ensah.core.services.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.dao.IElementPedagogiqueRepository;
import com.ensah.core.services.IElementPedagogiqueService;

import java.util.List;

@Service
public class IElementPedagogiqueServiceImpl implements IElementPedagogiqueService {
	
	@Autowired
    private IElementPedagogiqueRepository elementPedagogiqueRepository;
    


	@Override
    public ElementPedagogique saveElementPedagogique(ElementPedagogique element) {
        return elementPedagogiqueRepository.save(element);
    }

    @Override
    public ElementPedagogique updateElementPedagogique(ElementPedagogique element) {
        return elementPedagogiqueRepository.save(element);
    }

    @Override
    public void deleteElementPedagogique(Long id) {
        elementPedagogiqueRepository.deleteById(id);
    }

    @Override
    public ElementPedagogique getElementPedagogiqueById(Long id) {
        return elementPedagogiqueRepository.findById(id).orElse(null);
    }

    @Override
    public List<ElementPedagogique> getAllElementPedagogiques() {
        return elementPedagogiqueRepository.findAll();
    }

    @Override
    public List<ElementPedagogique> getElementsByNiveau_idNiveau(Long idNiveau) {
        return elementPedagogiqueRepository.findByNiveau_idNiveau(idNiveau);
    }

    @Override
    public List<ElementPedagogique> getElementsByCordonnateur(Enseignant cordonnateur) {
        return elementPedagogiqueRepository.findByCordonnateur(cordonnateur);
    }
    @Override
    public Enseignant getCordonnateurByElementPedagogiqueId(Long idElementPedagogique) {
        return elementPedagogiqueRepository.findCordonnateurByIdElementPedagogique(idElementPedagogique);
    }
}
