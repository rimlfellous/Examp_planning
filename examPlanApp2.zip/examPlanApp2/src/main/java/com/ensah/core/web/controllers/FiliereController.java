package com.ensah.core.web.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.Filiere;
import com.ensah.core.services.IFiliereService;

import java.util.List;

@Controller
public class FiliereController {

    @Autowired
    private IFiliereService filiereService;

    @GetMapping("/filieres")
    public String listFilieres(Model model) {
        List<Filiere> filieres = filiereService.getAllFilieres();
        model.addAttribute("filieres", filieres);
        return "listFilieres";
    }

    @GetMapping("/filiereForm")
    public String showFiliereForm(Model model) {
        model.addAttribute("filiere", new Filiere());
        return "filiereForm"; }


    @PostMapping("/saveFiliere")
    public String saveFiliere(@ModelAttribute("filiere") Filiere filiere) {
        filiereService.saveFiliere(filiere);
        return "redirect:/filieres";
    }

    @GetMapping("/editFiliereForm/{idFiliere}")
    public String showEditFiliereForm(@PathVariable Long idFiliere, Model model) {
        Filiere filiere = filiereService.getFiliereById(idFiliere);
        model.addAttribute("filiere", filiere);
        return "editFiliereForm";
    }

    @GetMapping("/deleteFiliere/{idFiliere}")
    public String deleteFiliere(@PathVariable Long idFiliere) {
        filiereService.deleteFiliere(idFiliere);
        return "redirect:/filieres";
    }
}
