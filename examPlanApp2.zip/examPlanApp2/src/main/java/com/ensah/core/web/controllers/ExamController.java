package com.ensah.core.web.controllers;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.Session;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.bo.TypeExamen;
import com.ensah.core.services.IElementPedagogiqueService;
import com.ensah.core.services.IEnseignantService;
import com.ensah.core.services.IExamenService;
import com.ensah.core.services.IGroupeService;
import com.ensah.core.services.ISalleService;
import com.ensah.core.services.ISurveillanceService;
import com.ensah.core.web.models.ExamDetailsDTO;

import jakarta.transaction.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ExamController {
	
	    
    private final IExamenService examenService;
    
    private final IElementPedagogiqueService elementPedagogiqueService;
    
    private final ISalleService salleService; 
    private final ISurveillanceService surveillanceService ;
    private final IGroupeService groupeService; 
    private final IEnseignantService enseignantService;

    

    public ExamController(IExamenService examenService, IElementPedagogiqueService elementPedagogiqueService, ISalleService salleService,ISurveillanceService surveillanceService, IGroupeService groupeService, IEnseignantService enseignantService) {
        this.examenService = examenService;
        this.elementPedagogiqueService = elementPedagogiqueService;
        this.salleService = salleService; 
		this.surveillanceService = surveillanceService;
		this.groupeService = groupeService  ;
		this.enseignantService = enseignantService;
    }


    @GetMapping("/exams/create")
    public String showCreateForm(Model model) {
        model.addAttribute("examen", new Examen());
        model.addAttribute("sessions", Session.values());
        model.addAttribute("semestres", Semestre.values());
        model.addAttribute("typeExamens", TypeExamen.values());
        model.addAttribute("elementPedagogiques", elementPedagogiqueService.getAllElementPedagogiques());
        model.addAttribute("salles", salleService.getAllSalles()); 
        model.addAttribute("groups", groupeService.getAllGroups());
        return "createExam";
    }


 

    @PostMapping("/exams/create")
    @Transactional
    public String createExam(@ModelAttribute Examen examen,
                             @RequestParam(name = "selectedSalles", required = false) List<Long> selectedSalles,
                             @RequestParam(name = "nbreSurveillants", defaultValue = "2") int nbreSurveillants,
                             @RequestParam(name = "assignType", defaultValue = "random") String assignType,
                             @RequestParam(name = "selectedGroup", required = false) Long selectedGroup) {
        // we save the examen first to generate its ID
        examen = examenService.saveExamen(examen);

        Long elementPedagogiqueId = examen.getElementPedagogique().getIdElementPedagogique();
        Enseignant cordonnateur = surveillanceService.getCordonnateurByElementPedagogiqueId(elementPedagogiqueId);

        List<Salle> salles = new ArrayList<>();
        if (selectedSalles != null && !selectedSalles.isEmpty()) {
            for (Long salleId : selectedSalles) {
                Salle salle = salleService.getSalleById(salleId);
                if (salle != null) {
                    salles.add(salle);
                }
            }
        }

        if (!salles.isEmpty()) {
            if ("random".equals(assignType)) {
                surveillanceService.assignSurveillantsRandomly(examen, salles, nbreSurveillants);
            } else if ("byGroup".equals(assignType) && selectedGroup != null) {
                surveillanceService.assignSurveillantsByGroup(examen, salles, nbreSurveillants, selectedGroup);
            }

            for (Salle salle : salles) {
                List<Surveillance> surveillances = surveillanceService.getSurveillancesBySalle(salle.getIdSalle());
                for (Surveillance surveillance : surveillances) {
                    surveillanceService.assignControlleurRandomly(surveillance);
                    surveillance.setEnseignant(cordonnateur);
                    surveillanceService.saveSurveillance(surveillance); // Save the updated surveillance
                }
            }
        }

        return "redirect:/exams";
    }

  
    @GetMapping("/exams")
    public String listExams(Model model) {
        List<Examen> exams = examenService.getAllExamen();

        List<ExamDetailsDTO> examDetailsList = new ArrayList<>();
        
        for (Examen examen : exams) {
            List<Surveillance> surveillances = surveillanceService.getSurveillancesByExamen(examen.getId());
            
            Set<Salle> salles = new HashSet<>();
            Set<Enseignant> surveillants = new HashSet<>();
            Enseignant cordonnateur = null;
            CadreAdministrateur controleurAbsence = null;
            String pv = examen.getPv();
            String rapport = examen.getRapport();
            String epreuve = examen.getEpreuve();
            int dureeReelle = examen.getDureeReelle();
            
            for (Surveillance surveillance : surveillances) {
                salles.add(surveillance.getSalle());
                surveillants.addAll(surveillance.getEnseignants());
                cordonnateur = surveillance.getEnseignant();
                controleurAbsence = surveillance.getCadreAdmin();
            }
            
            ExamDetailsDTO examDetails = new ExamDetailsDTO(examen, salles, cordonnateur, controleurAbsence, surveillants, pv, rapport, epreuve, dureeReelle);
            examDetailsList.add(examDetails);
        }

        model.addAttribute("examDetailsList", examDetailsList);
        return "listExams";
    }

    

        @GetMapping("/deleteexam/{id}")
        public String deleteExam(@PathVariable("id") Long id) {
            List<Surveillance> surveillances = surveillanceService.getSurveillancesByExamen(id);

            for (Surveillance surveillance : surveillances) {
                Set<Enseignant> enseignants = surveillance.getEnseignants();
                for (Enseignant enseignant : enseignants) {
                    enseignant.getAdditionalSurveillances().remove(surveillance);
                    enseignantService.saveEnseignant(enseignant);  
                }
                surveillance.getEnseignants().clear();
                surveillanceService.saveSurveillance(surveillance);  
            }

            surveillanceService.deleteByExamenId(id);

            examenService.deleteExamen(id);

            return "redirect:/exams"; 
        }

      
        
        @GetMapping("/editexam/{id}")
        public String showUpdateForm(@PathVariable Long id, Model model) {
            Examen examen = examenService.getExamenById(id);
            boolean isDatePassed = examen.getDate().before(new Date(System.currentTimeMillis()));
            model.addAttribute("examen", examen);
            model.addAttribute("isDatePassed", isDatePassed);
            model.addAttribute("sessions", Session.values());
            model.addAttribute("semestres", Semestre.values());
            model.addAttribute("typeExamens", TypeExamen.values());
            model.addAttribute("elementPedagogiques", elementPedagogiqueService.getAllElementPedagogiques());
            model.addAttribute("salles", salleService.getAllSalles());
            model.addAttribute("groups", groupeService.getAllGroups());
            return "editExam";
        }

        
        @PostMapping("/updateexam/{id}")
        @Transactional
        public String updateExam(@PathVariable Long id, @ModelAttribute Examen examen,
                                 @RequestParam(name = "selectedSalles", required = false) List<Long> selectedSalles,
                                 @RequestParam(name = "nbreSurveillants", defaultValue = "2") int nbreSurveillants,
                                 @RequestParam(name = "assignType", defaultValue = "random") String assignType,
                                 @RequestParam(name = "selectedGroup", required = false) Long selectedGroup,
                                 @RequestParam(name = "epreuveFile", required = false) MultipartFile epreuveFile,
                                 @RequestParam(name = "pvFile", required = false) MultipartFile pvFile,
                                 @RequestParam(name = "rapportFile", required = false) MultipartFile rapportFile) {
            Examen existingExam = examenService.getExamenById(id);

            if (existingExam == null) {
                return "redirect:/exams";
            }

            existingExam.setDate(examen.getDate());
            existingExam.setHeureDebut(examen.getHeureDebut());
            existingExam.setDureePrevue(examen.getDureePrevue());
            existingExam.setSession(examen.getSession());
            existingExam.setSemestre(examen.getSemestre());
            existingExam.setTypeExamen(examen.getTypeExamen());
            existingExam.setElementPedagogique(examen.getElementPedagogique());

            boolean isDatePassed = existingExam.getDate().before(new Date(System.currentTimeMillis()));
            if (isDatePassed) {
                existingExam.setDureeReelle(examen.getDureeReelle());
                existingExam.setEpreuve(saveFile(epreuveFile));
                existingExam.setPv(saveFile(pvFile));
                existingExam.setRapport(saveFile(rapportFile));
            }

            examenService.saveExamen(existingExam);

            List<Surveillance> existingSurveillances = surveillanceService.getSurveillancesByExamen(id);
            for (Surveillance surveillance : existingSurveillances) {
                Set<Enseignant> enseignants = surveillance.getEnseignants();
                for (Enseignant enseignant : enseignants) {
                    enseignant.getAdditionalSurveillances().remove(surveillance);
                    enseignantService.saveEnseignant(enseignant);
                }
                surveillance.getEnseignants().clear();
                surveillanceService.saveSurveillance(surveillance);
            }
            surveillanceService.deleteByExamenId(id);

            List<Salle> salles = new ArrayList<>();
            if (selectedSalles != null && !selectedSalles.isEmpty()) {
                for (Long salleId : selectedSalles) {
                    Salle salle = salleService.getSalleById(salleId);
                    if (salle != null) {
                        salles.add(salle);
                    }
                }
            }

            if (!salles.isEmpty()) {
                Long elementPedagogiqueId = existingExam.getElementPedagogique().getIdElementPedagogique();
                Enseignant cordonnateur = surveillanceService.getCordonnateurByElementPedagogiqueId(elementPedagogiqueId);

                if ("random".equals(assignType)) {
                    surveillanceService.assignSurveillantsRandomly(existingExam, salles, nbreSurveillants);
                } else if ("byGroup".equals(assignType) && selectedGroup != null) {
                    surveillanceService.assignSurveillantsByGroup(existingExam, salles, nbreSurveillants, selectedGroup);
                }

                for (Salle salle : salles) {
                    List<Surveillance> surveillances = surveillanceService.getSurveillancesBySalle(salle.getIdSalle());
                    for (Surveillance surveillance : surveillances) {
                        surveillanceService.assignControlleurRandomly(surveillance);
                        surveillance.setEnseignant(cordonnateur);
                        surveillanceService.saveSurveillance(surveillance);
                    }
                }
            }

            return "redirect:/exams"; 
        }

        private String saveFile(MultipartFile file) {
            if (file != null && !file.isEmpty()) {
                return file.getOriginalFilename();
            }
            return null;
        }



}




