package com.ensah.core.bo;

import jakarta.persistence.*;


@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name="Type_Personne")
public class Personne {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected Long idPersonne;

	private String nom;

	private String prenom;

	
	public Long getIdPersonne() {
		return idPersonne;
	}

	public void setIdPersonne(Long idPerson) {
		this.idPersonne = idPerson;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	@Override
	public String toString() {
		return "Utilisateur [idPerson=" + idPersonne + ", nom=" + nom + ", prenom=" + prenom + ", cin=" +"]";
	}

}