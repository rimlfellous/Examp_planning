package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Niveau;

public interface INiveauService {
    Niveau saveNiveau(Niveau niveau);
    Niveau updateNiveau(Niveau niveau);
    void deleteNiveau(Long id);
    Niveau getNiveauById(Long id);
    List<Niveau> getAllNiveaux();
}
