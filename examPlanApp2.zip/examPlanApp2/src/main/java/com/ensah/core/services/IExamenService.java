package com.ensah.core.services;
import com.ensah.core.bo.Examen;

import java.util.List;

import com.ensah.core.bo.Session;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.TypeExamen;


public interface IExamenService {

    Examen saveExamen(Examen examen);
    Examen updateExamen(Examen examen);
    void deleteExamen(Long id);
    Examen getExamenById(Long id);
    List<Examen> getAllExamen();
    List<Examen> getExamsBySemestre(Semestre semestre);
    List<Examen> getExamsBySession(Session session);
    List<Examen> getExamsByType(TypeExamen typeExamen);
    List<Examen> getExamsByElementPedagogique(String titreElementPedagogique);
    String generateDetailedExamReport(Long idExamen);
}
