package com.ensah.core.bo;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Surveillance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idS;

    @ManyToOne
    @JoinColumn(name = "id_Examen")
    private Examen examen;

    @ManyToOne
    @JoinColumn(name = "Cordonnateur")
    private Enseignant enseignant;
    
    @ManyToMany(mappedBy = "additionalSurveillances")
    private Set<Enseignant> enseignants;

    @ManyToOne
    @JoinColumn(name = "id_CardreAdmin")
    private CadreAdministrateur cadreAdmin;

    @ManyToOne
    @JoinColumn(name = "id_Salle")
    private Salle salle;
    
	public Surveillance() {
		super();
	}

	

	public Surveillance(Long idS, Examen examen, Enseignant enseignant, CadreAdministrateur cadreAdmin, Salle salle) {
		super();
		this.idS = idS;
		this.examen = examen;
		this.enseignant = enseignant;
		this.cadreAdmin = cadreAdmin;
		this.salle = salle;
	}
	



	public Surveillance(Long idS, Examen examen, Salle salle) {
		super();
		this.idS = idS;
		this.examen = examen;
		this.salle = salle;
	}



	public Salle getSalle() {
		return salle;
	}

	public void setSalle(Salle salle) {
		this.salle = salle;
	}

	public Long getIdS() {
		return idS;
	}

	public void setIdS(Long idS) {
		this.idS = idS;
	}

	public Examen getExamen() {
		return examen;
	}

	public void setExamen(Examen examen) {
		this.examen = examen;
	}

	public Enseignant getEnseignant() {
		return enseignant;
	}

	public void setEnseignant(Enseignant enseignant) {
		this.enseignant = enseignant;
	}

	public CadreAdministrateur getCadreAdmin() {
		return cadreAdmin;
	}

	public void setCadreAdmin(CadreAdministrateur cadreAdmin) {
		this.cadreAdmin = cadreAdmin;
	}



	public Set<Enseignant> getEnseignants() {
		return enseignants;
	}



	public void setEnseignants(Set<Enseignant> enseignants) {
		this.enseignants = enseignants;
	}

    
}

