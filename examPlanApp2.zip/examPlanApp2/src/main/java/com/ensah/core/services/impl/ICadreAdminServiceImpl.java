package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.dao.ICadreAdminRepository;
import com.ensah.core.dao.ISurveillanceRepository;
import com.ensah.core.services.ICadreAdminService;

@Service
@Transactional
public class ICadreAdminServiceImpl implements ICadreAdminService {
	@Autowired
    private ICadreAdminRepository cadreAdminRepository;
	@Autowired
    private ISurveillanceRepository surveillanceRepository;
    
	@Override
    public CadreAdministrateur saveCadreAdmin(CadreAdministrateur cadreAdmin) {
        return cadreAdminRepository.save(cadreAdmin);
    }

    @Override
    public CadreAdministrateur updateCadreAdmin(CadreAdministrateur cadreAdmin) {
        return cadreAdminRepository.save(cadreAdmin);
    }

    @Override
    public void deleteCadreAdmin(Long id) {
        cadreAdminRepository.deleteById(id);
    }

    @Override
    public CadreAdministrateur getCadreAdminById(Long id) {
        return cadreAdminRepository.findById(id).orElse(null);
    }

    @Override
    public List<CadreAdministrateur> getAllCadreAdmins() {
        return cadreAdminRepository.findAll();
    }

    @Override
    public List<Surveillance> getSurveillancesByCadreAdmin(Long idCadreAdmin) {
        return surveillanceRepository.findByCadreAdmin_IdPersonne(idCadreAdmin);
    }

    @Override
    public void assignSurveillanceToCadreAdmin(Long cadreAdminId, Long surveillanceId) {
        CadreAdministrateur cadreAdmin = cadreAdminRepository.findById(cadreAdminId).orElseThrow(() -> new RuntimeException("CadreAdmin not found"));
        Surveillance surveillance = surveillanceRepository.findById(surveillanceId).orElseThrow(() -> new RuntimeException("Surveillance not found"));
        surveillance.setCadreAdmin(cadreAdmin);
        surveillanceRepository.save(surveillance);
    }

}
