package com.ensah.core.services;


import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import java.util.List;

public interface IElementPedagogiqueService {
	    ElementPedagogique saveElementPedagogique(ElementPedagogique element);
	    ElementPedagogique updateElementPedagogique(ElementPedagogique element);
	    void deleteElementPedagogique(Long id);
	    ElementPedagogique getElementPedagogiqueById(Long id);
	    List<ElementPedagogique> getAllElementPedagogiques();
	    List<ElementPedagogique> getElementsByNiveau_idNiveau(Long idNiveau);
	    List<ElementPedagogique> getElementsByCordonnateur(Enseignant cordonnateur);
		Enseignant getCordonnateurByElementPedagogiqueId(Long idElementPedagogique);
	    
}



