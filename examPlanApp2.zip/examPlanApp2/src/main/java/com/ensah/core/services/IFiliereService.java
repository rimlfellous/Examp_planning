package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Filiere;

public interface IFiliereService {
    Filiere saveFiliere(Filiere filiere);
    Filiere updateFiliere(Filiere filiere);
    void deleteFiliere(Long id);
    Filiere getFiliereById(Long id);
    List<Filiere> getAllFilieres();
}
