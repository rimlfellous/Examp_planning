package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.Personne;
import com.ensah.core.dao.IPersonneRepository;
import com.ensah.core.services.IPersonneService;

@Service
@Transactional
public class IPersonneServiceImpl implements IPersonneService {
	@Autowired
    private IPersonneRepository personneRepository;
    


	@Override
    public Personne savePersonne(Personne personne) {
        return personneRepository.save(personne);
    }

    @Override
    public Personne updatePersonne(Personne personne) {
        return personneRepository.save(personne);
    }

    @Override
    public void deletePersonne(Long id) {
        personneRepository.deleteById(id);
    }

    @Override
    public Personne getPersonneById(Long id) {
        return personneRepository.findById(id).orElse(null);
    }

    @Override
    public List<Personne> getAllPersonnes() {
        return personneRepository.findAll();
    }

   // @Override
   // public List<Personne> getPersonnesByType(String type) {
    //    return personneRepository.findByTypePersonne(type);
   // }
}
