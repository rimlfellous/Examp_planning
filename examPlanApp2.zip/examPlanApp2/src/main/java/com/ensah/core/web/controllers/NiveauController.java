package com.ensah.core.web.controllers;
//NiveauController.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.Niveau;
import com.ensah.core.services.INiveauService;

import java.util.List;

@Controller
public class NiveauController {

 @Autowired
 private INiveauService niveauService;

 @GetMapping("/niveauForm")
 public String showNiveauForm(Model model) {
     model.addAttribute("niveau", new Niveau());
     return "niveauForm";
 }

 @PostMapping("/saveNiveau")
 public String saveNiveau(@ModelAttribute("niveau") Niveau niveau) {
     niveauService.saveNiveau(niveau);
     return "redirect:/niveaux";
 }

 @GetMapping("/niveaux")
 public String listNiveaux(Model model) {
     List<Niveau> niveaux = niveauService.getAllNiveaux();
     model.addAttribute("niveaux", niveaux);
     return "listNiveaux";
 }

 @GetMapping("/editNiveauForm/{idNiveau}")
 public String showEditNiveauForm(@PathVariable("idNiveau") Long id, Model model) {
     Niveau niveau = niveauService.getNiveauById(id);
     model.addAttribute("niveau", niveau);
     return "editNiveauForm";
 }

 @PostMapping("/updateNiveau/{idNiveau}")
 public String updateNiveau(@PathVariable("idNiveau") Long id, @ModelAttribute("niveau") Niveau niveau) {
     Niveau existingNiveau = niveauService.getNiveauById(id);
     existingNiveau.setTitre(niveau.getTitre());
     existingNiveau.setElementsPedagogiques(niveau.getElementsPedagogiques());
     niveauService.updateNiveau(existingNiveau);
     return "redirect:/niveaux";
 }

 @GetMapping("/deleteNiveau/{idNiveau}")
 public String deleteNiveau(@PathVariable("idNiveau") Long id) {
     niveauService.deleteNiveau(id);
     return "redirect:/niveaux";
 }
}
