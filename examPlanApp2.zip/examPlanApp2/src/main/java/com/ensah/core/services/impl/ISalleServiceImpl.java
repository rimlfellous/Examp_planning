package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.Salle;
import com.ensah.core.dao.ISalleRepository;
import com.ensah.core.services.ISalleService;

@Service
@Transactional
public class ISalleServiceImpl implements ISalleService {
	@Autowired
    private ISalleRepository salleRepository;
    


	@Override
    public Salle saveSalle(Salle salle) {
        return salleRepository.save(salle);
    }

    @Override
    public Salle updateSalle(Salle salle) {
        return salleRepository.save(salle);
    }

    @Override
    public void deleteSalle(Long id) {
        salleRepository.deleteById(id);
    }

    @Override
    public Salle getSalleById(Long id) {
        return salleRepository.findById(id).orElse(null);
    }

    @Override
    public List<Salle> getAllSalles() {
        List<Salle> salles = salleRepository.findAll();
        System.out.println("Retrieved salles: " + salles); 
        return salles;
    }

}
