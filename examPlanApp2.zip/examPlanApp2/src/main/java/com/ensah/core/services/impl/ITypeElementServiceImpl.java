package com.ensah.core.services.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.TypeElement;
import com.ensah.core.dao.ITypeElementRepository;
import com.ensah.core.services.ITypeElementService;

@Service
@Transactional
public class ITypeElementServiceImpl implements ITypeElementService {
	@Autowired
    private ITypeElementRepository typeElementRepository;
    


	@Override
    public TypeElement saveTypeElement(TypeElement typeElement) {
        return typeElementRepository.save(typeElement);
    }

    @Override
    public TypeElement updateTypeElement(TypeElement typeElement) {
        return typeElementRepository.save(typeElement);
    }

    @Override
    public void deleteTypeElement(Long id) {
        typeElementRepository.deleteById(id);
    }

    @Override
    public TypeElement getTypeElementById(Long id) {
        return typeElementRepository.findById(id).orElse(null);
    }

    @Override
    public List<TypeElement> getAllTypeElements() {
        return typeElementRepository.findAll();
    }
}
