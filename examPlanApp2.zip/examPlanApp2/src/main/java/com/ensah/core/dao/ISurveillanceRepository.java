package com.ensah.core.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Surveillance;
import java.util.List;

public interface ISurveillanceRepository extends JpaRepository<Surveillance, Long> {
	    List<Surveillance> findByExamen_id(Long idExamen);
	    List<Surveillance> findByEnseignant_IdPersonne(Long idEnseighant);
	    List<Surveillance> findByCadreAdmin_IdPersonne(Long idCadreAdmin);
	    List<Surveillance> findBySalle_idSalle(Long idSalle);
	    @Query("SELECT DISTINCT e FROM Surveillance s JOIN s.enseignant e")
	    List<Enseignant> findAssignedEnseignants();
	    List<Surveillance> findByExamenAndSalle(Examen examen, Salle salle);
		void deleteByExamenId(Long examenId);

	}
	    
