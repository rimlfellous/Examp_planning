package com.ensah.core.web.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.services.IElementPedagogiqueService;
import com.ensah.core.services.IEnseignantService;
import com.ensah.core.services.INiveauService;
import com.ensah.core.services.ITypeElementService;
@Controller
@RequestMapping("")
public class ElementPedagogiqueController {

    @Autowired
    private IElementPedagogiqueService elementPedagogiqueService;

    @Autowired
    private IEnseignantService enseignantService;

    @Autowired
    private INiveauService niveauService;

    @Autowired
    private ITypeElementService typeElementService;

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("elementPedagogique", new ElementPedagogique());
        model.addAttribute("enseignantList", enseignantService.getAllEnseignants());
        model.addAttribute("niveauList", niveauService.getAllNiveaux());
        model.addAttribute("typeElementList", typeElementService.getAllTypeElements());
        return "addElementPedagogique";
    }

    @PostMapping("/save")
    public String saveElementPedagogique(@ModelAttribute("elementPedagogique") ElementPedagogique elementPedagogique) {
        elementPedagogiqueService.saveElementPedagogique(elementPedagogique);
        return "redirect:/manage";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        ElementPedagogique elementPedagogique = elementPedagogiqueService.getElementPedagogiqueById(id);
        model.addAttribute("elementPedagogique", elementPedagogique);
        model.addAttribute("enseignantList", enseignantService.getAllEnseignants());
        model.addAttribute("niveauList", niveauService.getAllNiveaux());
        model.addAttribute("typeElementList", typeElementService.getAllTypeElements());
        return "editElementPedagogique";
    }

    @PostMapping("/update/{id}")
    public String updateElementPedagogique(@PathVariable("id") Long id, @ModelAttribute("elementPedagogique") ElementPedagogique elementPedagogique) {
        elementPedagogique.setIdElementPedagogique(id);
        elementPedagogiqueService.updateElementPedagogique(elementPedagogique);
        return "redirect:/manage";
    }

    @GetMapping("/delete/{id}")
    public String deleteElementPedagogique(@PathVariable("id") Long id) {
        elementPedagogiqueService.deleteElementPedagogique(id);
        return "redirect:/manage";
    }

    @GetMapping("/manage")
    public String showElementPedagogiqueList(Model model) {
        model.addAttribute("elementPedagogiques", elementPedagogiqueService.getAllElementPedagogiques());
        return "manageElementPedagogique";
    }
}
