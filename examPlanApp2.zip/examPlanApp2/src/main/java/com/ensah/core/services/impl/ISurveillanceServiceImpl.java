package com.ensah.core.services.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.dao.ICadreAdminRepository;
import com.ensah.core.dao.IElementPedagogiqueRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.ISurveillanceRepository;
import com.ensah.core.services.IElementPedagogiqueService;
import com.ensah.core.services.ISurveillanceService;



import jakarta.transaction.Transactional;

import java.util.Collections;
import java.util.List;

@Service
public class ISurveillanceServiceImpl implements ISurveillanceService {
	@Autowired
    private ISurveillanceRepository surveillanceRepository;
	@Autowired
    private IEnseignantRepository enseignantRepository;
	@Autowired
    private ICadreAdminRepository cadreAdminRepository;
	@Autowired
	private IElementPedagogiqueService elementPedagogiqueService;
	@Autowired
	private IElementPedagogiqueRepository elementPedagogiqueRepository;

	    
    
  
  

	@Override
    public Surveillance saveSurveillance(Surveillance surveillance) {
        return surveillanceRepository.save(surveillance);
    }

    @Override
    public List<Surveillance> getAllSurveillances() {
        return surveillanceRepository.findAll();
    }

    @Override
    public Surveillance getSurveillanceById(Long id) {
        return surveillanceRepository.findById(id).orElse(null);
    }

    @Override
    public List<Surveillance> getSurveillancesByExamen(Long idExamen) {
        return surveillanceRepository.findByExamen_id(idExamen);
    }

    @Override
    public List<Surveillance> getSurveillancesByEnseignant(Long idEnseignant) {
        return surveillanceRepository.findByEnseignant_IdPersonne(idEnseignant);
    }

    @Override
    public List<Surveillance> getSurveillancesByCadreAdmin(Long idCadreAdmin) {
        return surveillanceRepository.findByCadreAdmin_IdPersonne(idCadreAdmin);
    }

    @Override
    public List<Surveillance> getSurveillancesBySalle(Long idSalle) {
        return surveillanceRepository.findBySalle_idSalle(idSalle);
    }

    @Override
    @Transactional
    public void assignSurveillantsRandomly(Examen examen, List<Salle> salles, int nbreEnseignant) {
        List<Enseignant> allEnseignants = enseignantRepository.findAll();
        List<Enseignant> unavailableEnseignants = enseignantRepository.findUnavailableEnseignants(examen.getDate(), examen.getHeureDebut());

        allEnseignants.removeAll(unavailableEnseignants);
        Collections.shuffle(allEnseignants);

        for (Salle salle : salles) {
            if (allEnseignants.isEmpty()) {
                break; // Stop if we run out of available enseignants
            }

            List<Enseignant> selectedEnseignants = allEnseignants.subList(0, Math.min(nbreEnseignant, allEnseignants.size()));
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen);
            surveillance.setSalle(salle);
            surveillanceRepository.save(surveillance);

            for (Enseignant enseignant : selectedEnseignants) {
                enseignant.getAdditionalSurveillances().add(surveillance);
                enseignantRepository.save(enseignant);
            }

            allEnseignants.removeAll(selectedEnseignants); // Remove assigned enseignants
        }
    }

    @Override
    @Transactional
    public void assignSurveillantsByGroup(Examen examen, List<Salle> salles, int nbreEnseignant, Long idGroupe) {
        List<Enseignant> allEnseignants = enseignantRepository.findAll();
        List<Enseignant> unavailableEnseignants = enseignantRepository.findUnavailableEnseignants(examen.getDate(), examen.getHeureDebut());

        allEnseignants.removeAll(unavailableEnseignants);

        List<Enseignant> enseignantsByGroup = enseignantRepository.findByGroupe_IdGroupe(idGroupe);
        enseignantsByGroup.retainAll(allEnseignants);
        Collections.shuffle(enseignantsByGroup);

        for (Salle salle : salles) {
            if (enseignantsByGroup.isEmpty()) {
                break; // Stop if we run out of available enseignants in the group
            }

            List<Enseignant> selectedEnseignants = enseignantsByGroup.subList(0, Math.min(nbreEnseignant, enseignantsByGroup.size()));
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen);
            surveillance.setSalle(salle);
            surveillanceRepository.save(surveillance);

            for (Enseignant enseignant : selectedEnseignants) {
                enseignant.getAdditionalSurveillances().add(surveillance);
                enseignantRepository.save(enseignant);
            }

            enseignantsByGroup.removeAll(selectedEnseignants); // Remove assigned enseignants
        }
    }
   

 

    @Override
    public void assignControlleurRandomly(Surveillance surveillance) {
        List<CadreAdministrateur> allCadres = cadreAdminRepository.findAll();
        Collections.shuffle(allCadres);

        CadreAdministrateur selectedCadre = allCadres.get(0);

        surveillance.setCadreAdmin(selectedCadre);

        surveillanceRepository.save(surveillance);
    }

 
    @Override
    public Enseignant getCordonnateurByElementPedagogiqueId(Long idElementPedagogique) {
        ElementPedagogique elementPedagogique = elementPedagogiqueService.getElementPedagogiqueById(idElementPedagogique);
        if (elementPedagogique != null) {
            return elementPedagogique.getCordonnateur();
        } else {
            return null;
        }
    }
  
    @Override
    @Transactional
    public void addCoordinatorToSurveillance(Long elementPedagogiqueId, Long idExamen) {
        ElementPedagogique elementPedagogique = elementPedagogiqueRepository.findById(elementPedagogiqueId).orElse(null);
        
        if (elementPedagogique != null) {
            Enseignant coordinator = elementPedagogique.getCordonnateur();
            
            if (coordinator != null) {
                List<Surveillance> surveillances = surveillanceRepository.findByExamen_id(idExamen);
                for (Surveillance surveillance : surveillances) {
                    surveillance.setEnseignant(coordinator);
                    surveillanceRepository.save(surveillance);
                }
                
                System.out.println("Coordinator added to all surveillances for the element pedagogique.");
            } else {
                System.out.println("No coordinator found for the ElementPedagogique.");
            }
        } else {
            System.out.println("ElementPedagogique not found.");
        }
    }

  
    @Override
    @Transactional
    public void deleteByExamenId(Long examenId) {
        surveillanceRepository.deleteByExamenId(examenId);
    }

    

}
