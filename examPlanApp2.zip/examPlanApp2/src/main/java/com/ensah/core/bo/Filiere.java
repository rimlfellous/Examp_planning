package com.ensah.core.bo;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Filiere {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idFiliere;
	
	private String nomF;
	
	@OneToMany(mappedBy = "filiere", cascade = CascadeType.ALL)
    private Set<Enseignant> enseignants;
	

	public Filiere() {
		super();
	}


	public Filiere(Long idFiliere, String nomF, Set<Enseignant> enseignants) {
		super();
		this.idFiliere = idFiliere;
		this.nomF = nomF;
		this.enseignants = enseignants;
	}


	public Long getIdFiliere() {
		return idFiliere;
	}


	public void setIdFiliere(Long idFiliere) {
		this.idFiliere = idFiliere;
	}


	public String getNomF() {
		return nomF;
	}


	public void setNomF(String nomF) {
		this.nomF = nomF;
	}


	public Set<Enseignant> getEnseignants() {
		return enseignants;
	}


	public void setEnseignants(Set<Enseignant> enseignants) {
		this.enseignants = enseignants;
	}

}