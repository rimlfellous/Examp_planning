package com.ensah.core.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.Departement;
import com.ensah.core.services.IDepartementService;

import java.util.List;

@Controller
public class DepartementController {

    @Autowired
    private IDepartementService departementService;

    @GetMapping("/departements")
    public String listDepartements(Model model) {
        List<Departement> departements = departementService.getAllDepartements();
        model.addAttribute("departements", departements);
        return "listDepartements";
    }

    @GetMapping("/departementForm")
    public String showDepartementForm(Model model) {
        model.addAttribute("departement", new Departement());
        return "departementForm";
    }

    @PostMapping("/saveDepartement")
    public String saveDepartement(@ModelAttribute("departement") Departement departement) {
        departementService.saveDepartement(departement);
        return "redirect:/departements";
    }

    @GetMapping("/editDepartementForm/{idDepartement}")
    public String showEditDepartementForm(@PathVariable Long idDepartement, Model model) {
        Departement departement = departementService.getDepartementById(idDepartement);
        model.addAttribute("departement", departement);
        return "editDepartement";
    }

    @GetMapping("/deleteDepartement/{idDepartement}")
    public String deleteDepartement(@PathVariable Long idDepartement) {
        departementService.deleteDepartement(idDepartement);
        return "redirect:/departements";
    }
}
